public class RegressionAnalysis {

    public static void main(String[] args) {
        // Data
        double[] hoursStudied = {7, 4, 8, 5, 7, 3, 7};
        double[] performanceIndex = {91.0, 65.0, 45.0, 36.0, 66.0, 61.0, 63.0};

        // Linear Regression
        double[] linearCoefficients = calculateLinearRegression(hoursStudied, performanceIndex);
        double aLinear = linearCoefficients[0];
        double bLinear = linearCoefficients[1];
        double rmsErrorLinear = calculateRMSError(hoursStudied, performanceIndex, aLinear, bLinear, false);

        // Exponential Regression
        double[] expCoefficients = calculateExponentialRegression(hoursStudied, performanceIndex);
        double aExp = expCoefficients[0];
        double bExp = expCoefficients[1];
        double rmsErrorExp = calculateRMSError(hoursStudied, performanceIndex, aExp, bExp, true);

        // Output
        System.out.println("Linear Regression Coefficients: a = " + aLinear + ", b = " + bLinear);
        System.out.println("RMS Error for Linear Regression: " + rmsErrorLinear);
        System.out.println("Exponential Regression Coefficients: a = " + aExp + ", b = " + bExp);
        System.out.println("RMS Error for Exponential Regression: " + rmsErrorExp);
    }

    public static double[] calculateLinearRegression(double[] x, double[] y) {
        int n = x.length;
        double sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;

        for (int i = 0; i < n; i++) {
            sumX += x[i];
            sumY += y[i];
            sumXY += x[i] * y[i];
            sumXX += x[i] * x[i];
        }

        double b = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
        double a = (sumY - b * sumX) / n;

        return new double[]{a, b};
    }

    public static double[] calculateExponentialRegression(double[] x, double[] y) {
        int n = x.length;
        double[] logY = new double[n];
        for (int i = 0; i < n; i++) {
            logY[i] = Math.log(y[i]);
        }

        double[] linearCoefficients = calculateLinearRegression(x, logY);
        double a = Math.exp(linearCoefficients[0]);
        double b = linearCoefficients[1];

        return new double[]{a, b};
    }

    public static double calculateRMSError(double[] x, double[] y, double a, double b, boolean isExponential) {
        int n = x.length;
        double sumSquaredError = 0;

        for (int i = 0; i < n; i++) {
            double predicted;
            if (isExponential) {
                predicted = a * Math.exp(b * x[i]);
            } else {
                predicted = a + b * x[i];
            }
            sumSquaredError += Math.pow(predicted - y[i], 2);
        }

        return Math.sqrt(sumSquaredError / n);
    }
}
