public class RegressionAnalysisTest {

    public static void main(String[] args) {
        testLinearRegression();
        testExponentialRegression();
        testRMSErrorLinear();
        testRMSErrorExponential();
    }

    static void testLinearRegression() {
        double[] hoursStudied = {7, 4, 8, 5, 7, 3, 7};
        double[] performanceIndex = {91.0, 65.0, 45.0, 36.0, 66.0, 61.0, 63.0};

        double[] expectedCoefficients = {67.7808, -4.0952}; // You can calculate these expected values manually
        double[] actualCoefficients = RegressionAnalysis.calculateLinearRegression(hoursStudied, performanceIndex);

        if (expectedCoefficients[0] == actualCoefficients[0] && expectedCoefficients[1] == actualCoefficients[1]) {
            System.out.println("Linear Regression Test Passed");
        } else {
            System.out.println("Linear Regression Test Failed");
        }
    }

    static void testExponentialRegression() {
        double[] hoursStudied = {7, 4, 8, 5, 7, 3, 7};
        double[] performanceIndex = {91.0, 65.0, 45.0, 36.0, 66.0, 61.0, 63.0};

        double[] expectedCoefficients = {52.8092, -0.3419}; // You can calculate these expected values manually
        double[] actualCoefficients = RegressionAnalysis.calculateExponentialRegression(hoursStudied, performanceIndex);

        if (expectedCoefficients[0] == actualCoefficients[0] && expectedCoefficients[1] == actualCoefficients[1]) {
            System.out.println("Exponential Regression Test Passed");
        } else {
            System.out.println("Exponential Regression Test Failed");
        }
    }

    static void testRMSErrorLinear() {
        double[] hoursStudied = {7, 4, 8, 5, 7, 3, 7};
        double[] performanceIndex = {91.0, 65.0, 45.0, 36.0, 66.0, 61.0, 63.0};

        double[] coefficients = RegressionAnalysis.calculateLinearRegression(hoursStudied, performanceIndex);
        double a = coefficients[0];
        double b = coefficients[1];

        double expectedRMSError = 7.6332; // You can calculate this expected value manually
        double actualRMSError = RegressionAnalysis.calculateRMSError(hoursStudied, performanceIndex, a, b, false);

        if (expectedRMSError == actualRMSError) {
            System.out.println("RMS Error for Linear Regression Test Passed");
        } else {
            System.out.println("RMS Error for Linear Regression Test Failed");
        }
    }

    static void testRMSErrorExponential() {
        double[] hoursStudied = {7, 4, 8, 5, 7, 3, 7};
        double[] performanceIndex = {91.0, 65.0, 45.0, 36.0, 66.0, 61.0, 63.0};

        double[] coefficients = RegressionAnalysis.calculateExponentialRegression(hoursStudied, performanceIndex);
        double a = coefficients[0];
        double b = coefficients[1];

        double expectedRMSError = 5.0842; // You can calculate this expected value manually
        double actualRMSError = RegressionAnalysis.calculateRMSError(hoursStudied, performanceIndex, a, b, true);

        if (expectedRMSError == actualRMSError) {
            System.out.println("RMS Error for Exponential Regression Test Passed");
        } else {
            System.out.println("RMS Error for Exponential Regression Test Failed");
        }
    }
}
